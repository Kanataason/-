struct LightData
{
    int Type;
    float3 Padding0;

    float3 Position;
    float Range;

    float3 Direction;
    float Angle;

    float4 Color;

};
struct MaterialData
{
    float4 Color;
};

Texture2D gTexture : register(t0);
SamplerState gSampler : register(s0);

cbuffer ConstantBuffer : register(b0)
{
    matrix World;
    matrix View;
    matrix Projection;

    LightData Light;
    MaterialData Material;
};
struct PS_IN
{
    float4 pos : SV_POSITION;
    float3 normal : NORMAL;
    float2 uv : TEXCOORD0;
};

float4 main(PS_IN input) : SV_TARGET
{
    //����͒P�ʃx�N�g��������āA���ςŊp�x���o���ĂP�`�O�͈̔͂Ŏ��߂Ă���
    float3 N = normalize(input.normal);
    float3 L = normalize(-Light.Direction);

    float diffuse = saturate(dot(N, L));
    
    return gTexture.Sample(gSampler, input.uv) * Material.Color * Light.Color * diffuse;

}