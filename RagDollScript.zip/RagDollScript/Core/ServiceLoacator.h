﻿#pragma once

#include <d3dcompiler.h>
#include <d3d11.h>
#include "InputSystem.h"

class PhysicsSystem;
class CollisionManager;
class DebugDraw;

/// <summary>
/// 他のコンポーネントでも必要となる物を入れる構造体
/// </summary>
struct ServiceLoacator
{
    InputSystem* input = nullptr;
    ID3D11Device* device = nullptr;
    ID3D11DeviceContext* context = nullptr;
    DebugDraw* debag = nullptr;

    PhysicsSystem* physicsSystem = nullptr;
};