﻿#include <d3d11.h>
#define NOMINMAX
#include <Windows.h>

#include "GameManager.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

/// <summary>
/// Windowのメッセージ処理
/// </summary>
LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_DESTROY://ウィンドウが閉じたら終わらせる
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance,
    HINSTANCE,
    LPSTR,
    int nCmdShow)
{

    //設計図を宣言
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;//コールバックの関数指定
    wc.hInstance = hInstance;//ハンドルの取得
    wc.lpszClassName = L"MyWindowClass";//アプリケーションの名前

    //設計図をwindows Osに登録
    RegisterClass(&wc);


    //windowsを実際に生成
    HWND hwnd = CreateWindowEx(
        0,
        wc.lpszClassName,
        L"DirectX11",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        SCREEN_WIDTH,
        SCREEN_HEIGHT,
        nullptr,
        nullptr,
        hInstance,
        nullptr);

    ShowWindow(hwnd, nCmdShow);


    GameManager gameManager;

    gameManager.Initialize(hwnd);


    MSG msg = {};
    ShowCursor(FALSE);//カーソル非表示

    while (msg.message != WM_QUIT)//アプリを終了したら
    {
        //windowsから何か動作連絡が来ているか確認
        if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            continue;
        }
        else
        {

            gameManager.Update();
        }
    }
    ShowCursor(TRUE);

    gameManager.Release();

    UnregisterClass(wc.lpszClassName, hInstance);

    return static_cast<int>(msg.wParam);
}
