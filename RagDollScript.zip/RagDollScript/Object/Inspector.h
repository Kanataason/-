﻿#pragma once

class Inspector
{
public :

};