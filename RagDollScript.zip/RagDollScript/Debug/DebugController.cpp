﻿#include "DebugController.h"
#include "InputSystem.h"

void DebugController::Initialize(ServiceLoacator& loacator)
{
	_input = loacator.input;
}
void DebugController::Update(float deltaTime)
{

}