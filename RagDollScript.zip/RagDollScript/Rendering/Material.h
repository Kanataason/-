﻿#pragma once
#include <DirectXMath.h>
#include "Texture.h"
using namespace DirectX;
class Material
{
public :

    const XMFLOAT4& GetColor() const{ return Color; }
    void SetColor(const XMFLOAT4& color)
    {
        Color = color;
    }

    const std::wstring& GetTexturePath() const { return _texturePath; }
    void SetTexturePath(const std::wstring& path)
    {
        _texturePath = path; 
    }

    const std::shared_ptr<Texture>& GetTexture() const{ return _texture; }
    void SetTexture(const std::shared_ptr<Texture> texture)
    {
        _texture = texture;
    }

private:
    //初期はなにもなしloaderでデフォルトのパスがふられる
    std::wstring _texturePath = L"";
    std::shared_ptr<Texture> _texture = nullptr;
    XMFLOAT4 Color = { 1,1,1,1 };
};