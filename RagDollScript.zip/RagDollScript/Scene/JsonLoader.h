﻿#pragma once
#include <ThirdParty/nlohmann/json.hpp>
#include <string>
#include <vector>
#include <DirectXMath.h>
#include <unordered_map>

using json = nlohmann::json;
#include "ObjectType.h"
#include "Transform.h"

using namespace DirectX;

class JsonLoader
{
public :
	json LoadJsonData(const std::string& assetPath);

	ObjectData LoadGameObjectData(const json& root);
private:

	//各Jsonから値を取り出す
	ObjectType LoadObjectType(const json& root);
	Attribute LoadObjectAttribute(const json& root);
	std::string LoadPath(const json& root);
	Transform LoadTransform(const json& root);
	std::string LoadMaterial(const json& root);
	void LoadAnimationPath(const json& root, std::vector<AnimationData>& animationPaths);

	//取り出した値を変換する
	ObjectType ToObjectType(const std::string& type);
	Attribute ToObjectAttribute(const std::string& attribute);
};