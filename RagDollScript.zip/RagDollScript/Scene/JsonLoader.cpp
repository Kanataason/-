﻿#include <fstream>

#include "JsonLoader.h"

namespace
{
	// JSON上の文字列とObjectTypeの対応表
	const std::unordered_map<std::string, ObjectType> ObjectTypeList =
	{
		{"Triangle", ObjectType::Triangle},
		{"Quad",     ObjectType::Quad},
		{"Box",      ObjectType::Box},
		{"Player",   ObjectType::Player},
		{"Light",    ObjectType::Light},
		{"Camera",   ObjectType::Camera}
	};

	// JSON上の文字列とAttributeの対応表
	const std::unordered_map<std::string, Attribute> ObjectAttributeList =
	{
		{"File",      Attribute::File},
		{"Primitive", Attribute::Primitive},
		{"Other",     Attribute::Other}
	};
}

json JsonLoader::LoadJsonData(const std::string& assetPath)
{
	// JSONファイルを開いて内容を読み込む
	std::ifstream file(assetPath);

	if (!file.is_open())
	{
		throw std::runtime_error("Failed to open json file.");
	}

	json j;
	file >> j;
	return j;
}
ObjectType JsonLoader::LoadObjectType(const json& root)
{
	if (!root.contains("type") || !root["type"].is_string())
	{
		return ObjectType::None;
	}

	return ToObjectType(root["type"].get<std::string>());
}
Attribute JsonLoader::LoadObjectAttribute(const json& root)
{
    if (!root.contains("attribute") || !root["attribute"].is_string())
    {
        return Attribute::None;
    }

    return ToObjectAttribute(root["attribute"].get<std::string>());
}
Transform JsonLoader::LoadTransform(const json& root)
{
	Transform transform{};

	// Position [x, y, z] を読み込む
	if (root.contains("position") &&
		root["position"].is_array() &&
		root["position"].size() >= 3)
	{
		transform.Position.x = root["position"][0].get<float>();
		transform.Position.y = root["position"][1].get<float>();
		transform.Position.z = root["position"][2].get<float>();
	}

	// Scale [x, y, z] を読み込む
	if (root.contains("scale") &&
		root["scale"].is_array() &&
		root["scale"].size() >= 3)
	{
		transform.Scale.x = root["scale"][0].get<float>();
		transform.Scale.y = root["scale"][1].get<float>();
		transform.Scale.z = root["scale"][2].get<float>();
	}

	return transform;
}
std::string JsonLoader::LoadPath(const json& root)
{
	return root.value("path", "");
}
std::string JsonLoader::LoadMaterial(const json& root) 
{
	return root.value("material", "");
}
void JsonLoader::LoadAnimationPath(const json& root, std::vector<AnimationData>& animationPath)
{
	if (!root.contains("animations") ||!root["animations"].is_array())
	{
		return;
	}

	for (const auto& animation : root["animations"])
	{
		if (!animation.is_object())
		{
			continue;
		}

		const std::string name =animation.value("name", "");

		const std::string path =animation.value("path", "");

		// 名前またはパスが無効なアニメーションは登録しない
		if (name.empty() || path.empty())
		{
			continue;
		}

		animationPath.push_back({
			name,
			path
			});
	}
}

ObjectData JsonLoader::LoadGameObjectData(const json& root)
{
	ObjectData data = {};

	data.typeName = LoadObjectType(root);
	data.attribute = LoadObjectAttribute(root);
	data.modelPath = LoadPath(root);
	data.transform = LoadTransform(root);
	data.materialName = LoadMaterial(root);
	
	LoadAnimationPath(root,data.animationDatas);

	return data;
}

//分ける
Attribute JsonLoader::ToObjectAttribute(const std::string& attribute)
{
	auto it = ObjectAttributeList.find(attribute);

	if (it != ObjectAttributeList.end())
	{
		return it->second;
	}

	throw std::runtime_error(
		"Unknown ObjectAttribute: " + attribute
	);
}


ObjectType JsonLoader::ToObjectType(const std::string& type)
{
	auto it = ObjectTypeList.find(type);

	if (it != ObjectTypeList.end())
	{
		return it->second;
	}

	throw std::runtime_error(
		"Unknown ObjectType: " + type
	);
}