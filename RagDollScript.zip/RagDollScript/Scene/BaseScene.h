﻿#pragma once
#include <vector>
#include <iostream>
#include <string>

#include "Renderer.h"
#include "BaseSceneLoader.h"
#include "BaseGameObjectFactory.h"

#include "ServiceLoacator.h"

class PhysicsSystem;
class DebugDraw;
class GameObject;
class Camera;
class Light;

class BaseScene
{
public:
    BaseScene(PhysicsSystem* system) :_physicsSystem(system) {}

	virtual ~BaseScene() = default;

	virtual void Initialize(ServiceLoacator& context, GameObjectFactory& factory);

	virtual void Update(float deltaTime);

	virtual void Draw(Renderer& renderer, DebugDraw* debug);
	virtual void Release();

	//シーン上のオブジェクトを追加
	virtual void AddObject(std::unique_ptr<GameObject> objectList) ;

	//各オブジェクトを初期化
    virtual void SetObjectInfo(ServiceLoacator& context);

	const virtual std::vector<std::unique_ptr<GameObject>>& GetObjectList() const { return _objects; };

protected:
	//各シーンでシーン用のJsonファイルを設定
	std::string _sceneFilePath = "Asset/Data/TestData.json";

private:
    SceneLoader _sceneLoader{};
    PhysicsSystem* _physicsSystem = nullptr;

	std::shared_ptr<Camera>	_camera = nullptr;

	std::vector<std::shared_ptr<Light>> _lights;
	std::vector<std::unique_ptr<GameObject>> _objects;

};