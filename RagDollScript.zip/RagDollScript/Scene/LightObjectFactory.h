﻿#pragma once
class LightFactory
{
public:

};