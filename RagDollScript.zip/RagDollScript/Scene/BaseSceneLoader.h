﻿#pragma once
#include <string>

#include "JsonLoader.h"

class BaseScene;
class GameObjectFactory;

class SceneLoader
{
public :
	void LoadObjects(BaseScene& scene, std::string& loadPath, GameObjectFactory& factory);
private :
	JsonLoader _jsonLoader;
};